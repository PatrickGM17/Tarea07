public class MultiplicacionDeMatriz {
    static void multiplicarMatrices(int[][] matriz1, int[][] matriz2) {
        int[][] multiplicaciondeMatriz = new int[matriz1.length][matriz1[0].length];
        for (int y = 0; y < matriz1.length; y++) {
            for (int x = 0; x < matriz1[y].length; x++) {
                int Matriz1 = matriz1[y][x];
                int Matriz2 = matriz2[y][x];
                int suma = Matriz1 * Matriz2;
                multiplicaciondeMatriz[y][x] = suma;
            }
        }

        System.out.println("Suma");
        for (int x = 0; x < 62; x++) {
            System.out.print("_");
        }
        System.out.println();

        for (int y = 0; y < matriz1.length; y++) {
            for (int x = 0; x < matriz1[y].length; x++) {
                System.out.printf("%5d ", matriz1[y][x]);
            }
            System.out.print(" | ");

            for (int x = 0; x < matriz2[y].length; x++) {
                System.out.printf("%5d ", matriz2[y][x]);
            }
            System.out.print(" | ");

            for (int x = 0; x < multiplicaciondeMatriz[y].length; x++) {
                System.out.printf("%5d ", multiplicaciondeMatriz[y][x]);
            }
            System.out.print(" | ");
            System.out.println();
        }
    }


    public static void main(String[] args) {
        int[][] matriz1 = {
                {10, 12, 13},
                {30, 20, 17},
                {45, 31, 22},
        };
        int[][] matriz2 = {
                {8, 7, 5},
                {9, 5, 4},
                {8, 6, 9},
        };
        multiplicarMatrices(matriz1, matriz2);
    }
}


